from typing import Optional, Tuple

import numpy as np
import pandas as pd
import scipy.sparse as sp
from sklearn.decomposition import PCA, TruncatedSVD
from sklearn.neighbors import NearestNeighbors

from .core import SingleCellDataset


def scrublet(
    data: SingleCellDataset,
    expected_doublet_rate: float = 0.06,
    sim_doublet_ratio: float = 2.0,
    n_neighbors: int = 30,
    min_counts: int = 2,
    min_cells: int = 3,
    min_gene_variability_pctl: float = 85.0,
    n_prin_comps: int = 30,
    random_state: int = 0,
    verbose: bool = True,
) -> SingleCellDataset:

    if verbose:
        print("Scrublet: Starting doublet detection...")

    np.random.seed(random_state)

    X = data.X.copy()
    if sp.issparse(X):
        X = X.tocsr()

    n_obs = X.shape[0]

    if verbose:
        print(f"Scrublet: Filtering genes...")

    if sp.issparse(X):
        gene_counts = np.ravel(X.sum(axis=0))
        gene_cells = X.getnnz(axis=0)
    else:
        gene_counts = X.sum(axis=0)
        gene_cells = np.count_nonzero(X, axis=0)

    gene_mask = (gene_counts >= min_counts) & (gene_cells >= min_cells)
    X_filtered = X[:, gene_mask]

    if verbose:
        print(f"Scrublet: Kept {gene_mask.sum()}/{len(gene_mask)} genes")

    if sp.issparse(X_filtered):
        gene_mean = np.ravel(X_filtered.mean(axis=0))
        gene_var = np.ravel(X_filtered.power(2).mean(axis=0)) - gene_mean**2
    else:
        gene_mean = X_filtered.mean(axis=0)
        gene_var = X_filtered.var(axis=0)

    gene_mean[gene_mean == 0] = 1e-12
    gene_dispersion = gene_var / gene_mean

    disp_threshold = np.percentile(gene_dispersion, min_gene_variability_pctl)
    hvg_mask = gene_dispersion >= disp_threshold

    X_hvg = X_filtered[:, hvg_mask]

    if verbose:
        print(f"Scrublet: Selected {hvg_mask.sum()} variable genes")

    n_sim = int(n_obs * sim_doublet_ratio)

    if verbose:
        print(f"Scrublet: Simulating {n_sim} doublets...")

    parent1_idx = np.random.choice(n_obs, n_sim, replace=True)
    parent2_idx = np.random.choice(n_obs, n_sim, replace=True)

    if sp.issparse(X_hvg):
        X_sim = X_hvg[parent1_idx, :] + X_hvg[parent2_idx, :]
    else:
        X_sim = X_hvg[parent1_idx, :] + X_hvg[parent2_idx, :]

    if sp.issparse(X_hvg):
        X_combined = sp.vstack([X_hvg, X_sim])
    else:
        X_combined = np.vstack([X_hvg, X_sim])

    labels = np.concatenate([np.zeros(n_obs), np.ones(n_sim)])

    if verbose:
        print("Scrublet: Normalizing data...")

    if sp.issparse(X_combined):
        counts_per_cell = np.ravel(X_combined.sum(axis=1))
        counts_per_cell[counts_per_cell == 0] = 1
        from scipy.sparse import diags

        scale = diags(1 / counts_per_cell, 0)
        X_norm = scale @ X_combined
        X_norm = X_norm.log1p()
    else:
        counts_per_cell = X_combined.sum(axis=1).reshape(-1, 1)
        counts_per_cell[counts_per_cell == 0] = 1
        X_norm = X_combined / counts_per_cell
        X_norm = np.log1p(X_norm)

    if verbose:
        print(f"Scrublet: Computing {n_prin_comps} PCs...")

    n_features = X_norm.shape[1]
    n_components_actual = min(n_prin_comps, n_features)

    if n_components_actual < n_prin_comps:
        if verbose:
            print(
                f"Scrublet: Warning - Only {n_features} features available, using {n_components_actual} components"
            )

    if sp.issparse(X_norm):
        pca = TruncatedSVD(n_components=n_components_actual, random_state=random_state)
    else:
        pca = PCA(n_components=n_components_actual, random_state=random_state)

    X_pca = pca.fit_transform(X_norm)

    if verbose:
        print("Scrublet: Calculating doublet scores...")

    nbrs = NearestNeighbors(n_neighbors=n_neighbors, metric="euclidean")
    nbrs.fit(X_pca)

    _, indices = nbrs.kneighbors(X_pca[:n_obs])

    doublet_scores = np.zeros(n_obs)
    for i in range(n_obs):
        neighbor_labels = labels[indices[i]]
        doublet_scores[i] = neighbor_labels.mean()

    sim_scores = doublet_scores

    threshold = np.percentile(doublet_scores, 100 * (1 - expected_doublet_rate))

    predicted_doublets = doublet_scores > threshold

    data.obs["doublet_score"] = doublet_scores
    data.obs["predicted_doublet"] = predicted_doublets

    if verbose:
        n_doublets = predicted_doublets.sum()
        pct_doublets = 100 * n_doublets / n_obs
        print(f"Scrublet: Detected {n_doublets} doublets ({pct_doublets:.1f}%)")
        print(f"Scrublet: Threshold = {threshold:.3f}")

    return data


def filter_doublets(
    data: SingleCellDataset,
    doublet_score_threshold: Optional[float] = None,
    use_prediction: bool = True,
) -> SingleCellDataset:
    if doublet_score_threshold is not None:
        if "doublet_score" not in data.obs.columns:
            raise ValueError("doublet_score not found. Run scrublet() first.")
        mask = data.obs["doublet_score"] <= doublet_score_threshold
    elif use_prediction and "predicted_doublet" in data.obs.columns:
        mask = ~data.obs["predicted_doublet"]
    else:
        raise ValueError("No doublet information found.")

    n_removed = (~mask).sum()
    print(f"Removing {n_removed} doublets, keeping {mask.sum()} cells")

    return data[mask, :]


def detect_outliers(
    data: SingleCellDataset,
    metric: str = "total_counts",
    n_mads: float = 5.0,
    method: str = "both",
) -> SingleCellDataset:

    if metric not in data.obs.columns:
        raise ValueError(
            f"{metric} not found in obs. Run calculate_qc_metrics() first."
        )

    values = data.obs[metric].values
    median = np.median(values)
    mad = np.median(np.abs(values - median))

    if mad == 0:
        mad = 1e-10

    mad_scores = np.abs(values - median) / mad

    if method == "both":
        outliers = mad_scores > n_mads
    elif method == "lower":
        outliers = (values < median) & (mad_scores > n_mads)
    elif method == "upper":
        outliers = (values > median) & (mad_scores > n_mads)
    else:
        raise ValueError("method must be 'both', 'lower', or 'upper'")

    data.obs[f"is_outlier_{metric}"] = outliers

    n_outliers = outliers.sum()
    print(f"Detected {n_outliers} outlier cells based on {metric} (>{n_mads} MADs)")

    return data
